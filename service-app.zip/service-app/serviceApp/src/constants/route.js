import LOGIN from '../screens/Login';

export default ROUTES = {
  LOGIN
}
