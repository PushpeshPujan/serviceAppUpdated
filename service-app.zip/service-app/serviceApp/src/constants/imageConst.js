export default imageConstantURI = {

    brand:{ src: require('../../assets/images/logo.png'),
    label: 'blood',
    },
     
   
    profileImage: {
        src: require('../../assets/images/user.png'),
        label: 'profileImage',
        uri:"",
    }
}
